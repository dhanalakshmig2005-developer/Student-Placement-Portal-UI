# CampusConnect — Student Placement Portal UI

Frontend demo built with HTML5, CSS3, Bootstrap 5, and JavaScript.

## Features
- Browse sample job opportunities and eligibility
- Search by role/company and filter by department
- View placement events
- Click Apply Now to add a demo application and see its status
- Responsive desktop/mobile layout

## Run locally
1. Extract this folder.
2. Open `index.html` in a browser, or use VS Code + Live Server.
3. Bootstrap loads from a CDN, so internet access is needed for Bootstrap styling.

## Note
This is frontend-only demo content. Applications are added to the page during the current session only; there is no real authentication, backend, or database. Job listings, event dates, and statuses are examples.

## Upload to GitHub
1. Sign in at GitHub and click **New repository**.
2. Name it `student-placement-portal-ui`.
3. Create the repository.
4. Click **Add file → Upload files**.
5. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
6. Click **Commit changes**.

## Publish using GitHub Pages
Repository **Settings → Pages → Deploy from a branch**; select `main` and `/ (root)`, then Save. GitHub will show the published site URL there.
